// This file is part of the course TPV2@UCM - Samir Genaim

#include "SDLNetUtils.h"

Uint8 SDLNetUtils::buffer[bufferSize_];
